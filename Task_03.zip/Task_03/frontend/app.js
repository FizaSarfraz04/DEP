import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import HomePage from './pages/HomePage.js';
import ProductPage from './pages/productPage.js/index.js';

function App() {
    return (
        <Router>
            <div className="App">
                <Switch>
                    <Route path="/" component={HomePage} exact />
                    <Route path="/product/:id" component={ProductPage} />
                </Switch>
            </div>
        </Router>
    );
}

export default App;
