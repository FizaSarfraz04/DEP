

document.addEventListener('DOMContentLoaded', () => {
    const socket = io();
  
    // Chat Elements
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    const messages = document.getElementById('messages');
  
    
    chatForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = chatInput.value.trim();
      if (msg) {
        socket.emit('chat message', msg);
        chatInput.value = '';
      }
    });
  
    
    socket.on('chat message', (msg) => {
      const item = document.createElement('li');
      item.textContent = msg;
      messages.appendChild(item);
      messages.scrollTop = messages.scrollHeight;
    });
  
    // Notifications
    const notificationForm = document.getElementById('notification-form');
    const notificationInput = document.getElementById('notification-input');
    const notifications = document.getElementById('notifications');
  
   
    notificationForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const notification = notificationInput.value.trim();
      if (notification) {
        socket.emit('notification', notification);
        notificationInput.value = '';
      }
    });
  
    
    socket.on('notification', (data) => {
      const item = document.createElement('li');
      item.textContent = data;
      notifications.appendChild(item);
      notifications.scrollTop = notifications.scrollHeight;
    });
  });
  