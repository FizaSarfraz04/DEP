
module.exports = (io) => {
    io.on('connection', (socket) => {
      console.log('A user connected:', socket.id);
  
      // Handle chat messages
      socket.on('chat message', (msg) => {
        // Broadcast the message to all connected clients
        io.emit('chat message', msg);
      });
  
      // Handle notifications
      socket.on('notification', (data) => {
        // Broadcast the notification to all connected clients
        io.emit('notification', data);
      });
  
      socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
      });
    });
  };
  