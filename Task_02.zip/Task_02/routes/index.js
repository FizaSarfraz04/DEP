const express = require('express');
const router = express.Router();
const Post = require('../Models/post');  

router.get('/', async (req, res) => {
    const posts = await Post.find({});
    res.render('index', { posts });
});

module.exports = router;
