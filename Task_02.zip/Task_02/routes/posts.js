const express = require('express');
const router = express.Router();
const Post = require('../Models/post');  

router.get('/new', (req, res) => {
    res.render('new');
});

router.post('/', async (req, res) => {
    const { title, content } = req.body;
    await Post.create({ title, content });
    res.redirect('/');
});

router.get('/:id', async (req, res) => {
    const post = await Post.findById(req.params.id);
    res.render('post', { post });
});

router.get('/:id/edit', async (req, res) => {
    const post = await Post.findById(req.params.id);
    res.render('edit', { post });
});

router.put('/:id', async (req, res) => {
    const { title, content } = req.body;
    await Post.findByIdAndUpdate(req.params.id, { title, content });
    res.redirect(`/posts/${req.params.id}`);
});

router.delete('/:id', async (req, res) => {
    await Post.findByIdAndDelete(req.params.id);
    res.redirect('/');
});

module.exports = router;
